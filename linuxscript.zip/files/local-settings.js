// PeepoPog ff settings file de cron/artists/

// Add this file to C:\Program Files\Mozilla Firefox\defaults\pref
// Should work peepopog
// Also make sure to set permissions to this file so that it can only be modified or deleted by an Administrator.

pref("general.config.obscure_value", 0);
pref("general.config.filename", "mozilla.cfg");